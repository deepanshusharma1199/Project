from mailcap import show
from tkinter import Tk, TOP, Label, X, GROOVE, Frame, RIDGE, Entry, Text, Button, Scrollbar, HORIZONTAL, VERTICAL, \
    BOTTOM, RIGHT, Y, BOTH, StringVar, END, Toplevel, messagebox
from tkinter.ttk import Treeview, Combobox

import pymysql
import requests
import json
import smtplib as s


class Student:
     def __init__(self,root):
         self.root=root
         self.root.title("Student Manegement")
         self.root.geometry("1350x700+0+0")

         title=Label(self.root,text="Student Management system",bd=10,relief=GROOVE,font=("times new roman",40,"bold"),bg="yellow",fg="red")
         title.pack(side=TOP,fill=X)

      #=====variables=====
         self.Roll_No_var = StringVar()
         self.Name_var = StringVar()
         self.Email_var = StringVar()
         self.Gender_var = StringVar()
         self.DOB_var = StringVar()
         self.contact_var = StringVar()
         self.search_by=StringVar()
         self.search=StringVar()
      #====manage frame=====
         Manage=Frame(self.root,bd=4,relief=RIDGE,bg="red")
         Manage.place(x=20,y=100,width=540,height=560)

         m_title = Label(Manage, text="Student Mangement", bg="red", fg="white", font=("times new roman", 20, "bold"))
         m_title.grid(row=0, columnspan=2, pady=10)

         roll_no = Label(Manage, text="Roll No.", bg="red", fg="white", font=("times new roman", 20, "bold"))
         roll_no.grid(row=1, column=0, pady=10,padx=20,sticky="w")

         txt_roll_no = Entry(Manage,textvariable=self.Roll_No_var,font=("times new roman", 15, "bold"),bd=5,relief=GROOVE)
         txt_roll_no.grid(row=1, column=1, pady=10, padx=20, sticky="w")

         name = Label(Manage, text="Name", bg="red", fg="white", font=("times new roman", 20, "bold"))
         name.grid(row=2, column=0, pady=10, padx=20, sticky="w")

         txt_name = Entry(Manage,textvariable=self.Name_var, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
         txt_name.grid(row=2, column=1, pady=10, padx=20, sticky="w")

         Email = Label(Manage, text="Email", bg="red", fg="white", font=("times new roman", 20, "bold"))
         Email.grid(row=3, column=0, pady=10, padx=20, sticky="w")

         txt_Email= Entry(Manage,textvariable=self.Email_var, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
         txt_Email.grid(row=3, column=1, pady=10, padx=20, sticky="w")

         Gender = Label(Manage, text="Gender", bg="red", fg="white", font=("times new roman", 20, "bold"))
         Gender.grid(row=4, column=0, pady=10, padx=20, sticky="w")

         combo_gender=Combobox(Manage,textvariable=self.Gender_var, font=("times new roman", 13, "bold"),state='readonly')
         combo_gender['values']=("male","female","others")
         combo_gender.grid(row=4, column=1, pady=10, padx=10)

         DOB = Label(Manage, text="D.O.B", bg="red", fg="white", font=("times new roman", 20, "bold"))
         DOB.grid(row=5, column=0, pady=10, padx=20, sticky="w")

         txt_DOB = Entry(Manage,textvariable=self.DOB_var, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
         txt_DOB.grid(row=5, column=1, pady=10, padx=20, sticky="w")

         Address= Label(Manage, text="Address", bg="red", fg="white", font=("times new roman", 20, "bold"))
         Address.grid(row=6, column=0, pady=10, padx=20, sticky="w")

         self.txt_Address = Text(Manage,width=70,height=12,font=("",4))
         self.txt_Address.grid(row=6, column=1, pady=10, padx=20, sticky="w")

         phone = Label(Manage, text="contact", bg="red", fg="white", font=("times new roman", 20, "bold"))
         phone.grid(row=7, column=0, pady=10, padx=20, sticky="w")

         txt_phone= Entry(Manage,textvariable=self.contact_var, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
         txt_phone.grid(row=7, column=1, pady=10, padx=20, sticky="w")

         #=====button frame=====
         btn = Frame(Manage, bd=4, relief=RIDGE, bg="blue")
         btn.place(x=10, y=490, width=510)

         Add = Button(btn,text="ADD",width=10,command=self.add_student).grid(row=0,column=0,padx=10,pady=10)
         Update = Button(btn, text="Update", width=10,command=self.update_self).grid(row=0, column=1, padx=10, pady=10)
         Dlete = Button(btn, text="Delete", width=10,command=self.delete_data).grid(row=0, column=2, padx=10, pady=10)
         Clear = Button(btn, text="Clear", width=10,command=self.clear).grid(row=0, column=3, padx=10, pady=10)
         Messeage = Button(btn, text="Message", width=10,command=self.messeage).grid(row=0, column=4, padx=10, pady=10)

      #====detail frame====
         Detail = Frame(self.root, bd=4, relief=RIDGE, bg="red")
         Detail.place(x=600, y=100, width=870, height=560)

         search = Label(Detail, text="Search By", bg="red", fg="white", font=("times new roman", 20, "bold"))
         search.grid(row=0, column=0, pady=10, padx=20, sticky="w")

         combo_search = Combobox(Detail,textvariable=self.search_by ,font=("times new roman", 13, "bold"), state='readonly')
         combo_search['values'] = ("Roll_No", "Name", "Email","Gender")
         combo_search.grid(row=0, column=1, pady=10, padx=20)

         txt_search= Entry(Detail,textvariable=self.search ,font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
         txt_search.grid(row=0, column=2, pady=10, padx=20, sticky="w")

         btn_search = Button(Detail, text="Search", width=10,command=self.search_data).grid(row=0, column=3, padx=10, pady=10)
         showall = Button(Detail, text="Show all", width=10,command=self.fetch_data).grid(row=0, column=4, padx=8, pady=10)

         #=======table frame======
         Table = Frame(Detail, bd=4, relief=RIDGE, bg="red")
         Table.place(x=30, y=50, width=800, height=500)

         scroll_x = Scrollbar(Table, orient=HORIZONTAL)
         scroll_Y = Scrollbar(Table, orient=VERTICAL)
         self.Student_table = Treeview(Table,columns=("roll","name","Email","Gender","DOB","Address","Contact"),xscrollcommand=scroll_x.set, yscrollcommand=scroll_Y.set)
         scroll_x.pack(side=BOTTOM,fill=X)
         scroll_Y.pack(side=RIGHT, fill=Y)
         scroll_x.config(command=self.Student_table.xview)
         scroll_Y.config(command=self.Student_table.yview)
         self.Student_table.heading("roll",text="Roll NO")
         self.Student_table.heading("name", text="Name")
         self.Student_table.heading("Email", text="Email")
         self.Student_table.heading("Gender", text="Gender")
         self.Student_table.heading("DOB", text="DOB")
         self.Student_table.heading("Address", text="Address")
         self.Student_table.heading("Contact", text="Contact")
         self.Student_table['show']='headings'
         self.Student_table.column("roll",width=100)
         self.Student_table.column("name", width=150)
         self.Student_table.column("Email", width=160)
         self.Student_table.column("Gender", width=100)
         self.Student_table.column("DOB", width=100)
         self.Student_table.column("Address", width=170)
         self.Student_table.column("Contact", width=155)
         self.Student_table.pack(fill=BOTH,expand=1)
         self.Student_table.bind("<ButtonRelease-1>",self.get_cursor)
         self.fetch_data()
     def add_student(self):
         if self.Roll_No_var.get()=="" or self.Name_var.get()=="":
             messagebox.showerror("Error","All fields are required")
         else:
            con=pymysql.connect(host="localhost",user="root",password="",database="deepanshu")
            cur=con.cursor()
            cur.execute("insert into student values(%s,%s,%s,%s,%s,%s,%s)",( self.Roll_No_var.get(),
                                                                          self.Name_var.get(),
                                                                          self.Email_var.get(),
                                                                          self.Gender_var.get(),
                                                                          self.DOB_var.get(),
                                                                          self.txt_Address.get('1.0',END),
                                                                          self.contact_var.get()
                                                                          ))
            con.commit()
            self.fetch_data()
            self.clear()
            con.close()
            messagebox.showinfo("Succes","data add sucessfull")



     def fetch_data(self):
         con = pymysql.connect(host="localhost", user="root", password="", database="deepanshu")
         cur = con.cursor()
         cur.execute("select * from student")
         rows=cur.fetchall()
         if len(rows)!=0:
             self.Student_table.delete(*self.Student_table.get_children())
             for row in rows:
                   self.Student_table.insert('',END,values=row)
             con.commit()
         con.close()
     def clear(self):
         self.Roll_No_var.set("")
         self.Name_var.set("")
         self.Email_var.set("")
         self.Gender_var.set("")
         self.DOB_var.set("")
         self.txt_Address.delete("1.0", END)
         self.contact_var.set("")
     def get_cursor(self,ev):
         curosor_row=self.Student_table.focus()
         contents=self.Student_table.item(curosor_row)
         row=contents['values']
         print(row)
         self.Roll_No_var.set(row[0])
         self.Name_var.set(row[1])
         self.Email_var.set(row[2])
         self.Gender_var.set(row[3])
         self.DOB_var.set(row[4])
         self.txt_Address.delete("1.0", END)
         self.txt_Address.insert(END,row[5])
         self.contact_var.set(row[6])
     def update_self(self):
         con = pymysql.connect(host="localhost", user="root", password="", database="deepanshu")
         cur = con.cursor()
         cur.execute("update student set Name=%s,Email=%s,Gender=%s,DOB=%s,Address=%s,contact=%s where Roll_No=%s", (
                                                                                                                     self.Name_var.get(),
                                                                                                                     self.Email_var.get(),
                                                                                                                     self.Gender_var.get(),
                                                                                                                     self.DOB_var.get(),
                                                                                                                     self.txt_Address.get('1.0', END),
                                                                                                                     self.contact_var.get(),
                                                                                                                     self.Roll_No_var.get(),
                                                                                                                     ))
         con.commit()
         self.fetch_data()
         self.clear()
         con.close()
         messagebox.showinfo("Sucess","data updated succesfully")
     def delete_data(self):
         con = pymysql.connect(host="localhost", user="root", password="", database="deepanshu")
         cur = con.cursor()
         cur.execute("delete from student where Roll_No=%s",self.Roll_No_var.get())
         con.commit()
         con.close()
         self.fetch_data()
         self.clear()
         messagebox.showinfo("Sucessfull","data delete sucessfully")
     def search_data(self):
         con = pymysql.connect(host="localhost", user="root", password="", database="deepanshu")
         cur = con.cursor()
         cur.execute("select * from student where "+str(self.search_by.get())+"="+str(self.search.get()))
         rows = cur.fetchall()
         if len(rows) != 0:
             self.Student_table.delete(*self.Student_table.get_children())
             for row in rows:
                 self.Student_table.insert('', END, values=row)
             con.commit()
         con.close()
     def new_window(self):
         top=Toplevel()
         top.title("Send SMS")
         top.geometry("500x500+0+0")

         self.number_var=StringVar()

         frame = Frame(top, bd=4, relief=RIDGE, bg="red")
         frame.place(x=20, y=20, width=450, height=450)

         No = Label(frame, text="Phone_Number", bg="red", fg="white", font=("times new roman", 20, "bold"))
         No.grid(row=1, column=0, pady=10, padx=9, sticky="w")

         No_txt = Entry(frame,textvariable=self.number_var, font=("times new roman", 15, "bold"), bd=5,relief=GROOVE)
         No_txt.grid(row=1, column=1, pady=10, padx=10, sticky="w")

         messeage = Label(frame, text="Messeage", bg="red", fg="white", font=("times new roman", 20, "bold"))
         messeage.grid(row=10, column=0, pady=40, padx=9, sticky="w")


         self.txt_messeage = Text(frame,width=70,height=10,font=("",4))
         self.txt_messeage.grid(row=10, column=1, pady=20, padx=10, sticky="w")

         Send = Button(frame, text="Send", width=20,height=2,command=self.send_sms).grid(row=30,column=0,padx=10,pady=150)
     def send_sms(self):
         if self.number_var.get()=="":
             messagebox.showerror("Error","phone number required")
         else:
            url=' https://www.fast2sms.com/dev/bulk'
            params={
             'authorization':'pf8WlSVQT2F3RH9MwruK0zXoA7Bbqs1yeDNGLIiJ5nYxma6UPCtfvizHksc2axGbEY7jW5euATrmJUI1',
             'sender_id':'FSTSMS',
             'message': self.txt_messeage.get('1.0',END),
             'language':'english',
             'route':'p',
             'numbers':self.number_var.get()
             }
            response= requests.get(url,params=params)
            dic=response.json()
            print(dic)
            messagebox.showinfo("success","message send suceesfully")

     def messeage(self):
         send = Toplevel()
         send.title("Send Throw")
         send.geometry("300x300+0+0")

         frame_1 = Frame(send, bd=4, relief=RIDGE, bg="red")
         frame_1.place(x=20, y=20, width=250, height=250)

         SMS = Button(frame_1, text="SMS", width=10,command=self.new_window)
         SMS.place(x=75,y=20)

         SMS_all = Button(frame_1, text="SMS_all",width=10,command=self.all_student)
         SMS_all.place(x=75, y=90)

         # E_mail = Button(frame_1, text="E_mail", width=10,command=self.Email)
         # E_mail.place(x=75, y=150)
         #
         # E_mail_all = Button(frame_1, text="E_mail_all",width=10,command=self.send_email_all)
         # E_mail_all.place(x=75, y=210)


     # def Email(self):
     #     mail = Toplevel()
     #     mail.title("Send E_mail")
     #     mail.geometry("500x500+0+0")
     #
     #     self.password_var=StringVar()
     #     self.mail_var=StringVar()
     #
     #     frame_2 = Frame(mail, bd=4, relief=RIDGE, bg="red")
     #     frame_2.place(x=20, y=20, width=450, height=450)
     #
     #     Mail = Label(frame_2, text="E_mail", bg="red", fg="white", font=("times new roman", 20, "bold"))
     #     Mail.grid(row=1, column=0, pady=10, padx=9, sticky="w")
     #
     #     Mail_txt = Entry(frame_2,textvariable=self.mail_var, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
     #     Mail_txt.grid(row=1, column=1, pady=10, padx=20, sticky="w")
     #
     #     Messeage = Label(frame_2, text="Messeage", bg="red", fg="white", font=("times new roman", 20, "bold"))
     #     Messeage.grid(row=2, column=0, pady=40, padx=9, sticky="w")
     #
     #     self.txt_Messeage = Text(frame_2, width=70, height=10, font=("", 4))
     #     self.txt_Messeage.grid(row=2, column=1, pady=20, padx=20, sticky="w")
     #
     #     password = Label(frame_2, text="password", bg="red", fg="white", font=("times new roman", 20, "bold"))
     #     password.grid(row=3, column=0, pady=10, padx=9, sticky="w")
     #
     #     password_txt = Entry(frame_2,show='*',textvariable=self.password_var, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
     #     password_txt.grid(row=3, column=1, pady=10, padx=20, sticky="w")
     #
     #     Send_Email = Button(frame_2, text="Send", width=20, height=2, command=self.mail).grid(row=30, column=0, padx=10,
     #                                                                                       pady=150)
     # def mail(self):
     #     if self.mail_var.get()=="" or self.password_var.get()=="":
     #         messagebox.showerror("ERROR","E_mail and Password must required")
     #     else:
     #       ob=s.SMTP("smtp.gmail.com",587)
     #       ob.starttls()
     #       ob.login("deepanshusharma1199@gmail.com",self.password_var.get())
     #       subject="Student Mangement"
     #       msse="Subject:{}\n\n{}".format(subject,self.txt_Messeage.get('1.0',END))
     #       ob.sendmail("deepanshusharma1199",self.mail_var.get(),msse)
     #       messagebox.showinfo("SUCCESFULL","E_mail send succesfully")

     def all_student(self):
         all = Toplevel()
         all.title("Send SMS to all student")
         all.geometry("450x350+0+0")

         frame_3 = Frame(all, bd=4, relief=RIDGE, bg="red")
         frame_3.place(x=20, y=20, width=400, height=300)

         Messeage_all = Label(frame_3, text="Messeage", bg="red", fg="white", font=("times new roman", 20, "bold"))
         Messeage_all.grid(row=1, column=0, pady=40, padx=9, sticky="w")

         self.txt_Messeage_all = Text(frame_3, width=65, height=15, font=("", 4))
         self.txt_Messeage_all.grid(row=1, column=1, pady=20, padx=10, sticky="w")

         messeage = Button(frame_3, text="Send", width=20, height=2,command=self.send_all).grid(row=30, column=0,padx=10,pady=50)
     def send_all(self):
         con = pymysql.connect(host="localhost", user="root", password="", database="deepanshu")
         cur = con.cursor()
         cur.execute("select * from student")
         rows = cur.fetchall()
         if len(rows) != 0:
               j=1
               for i in range(len(rows)):
                  cur.execute("select contact from student where Roll_No="+str(j))
                  j=j+1
                  conta = cur.fetchall()
                  for k in conta:
                      k1=k
                      print(k1)
                  url = ' https://www.fast2sms.com/dev/bulk'
                  params = {
                      'authorization': 'pf8WlSVQT2F3RH9MwruK0zXoA7Bbqs1yeDNGLIiJ5nYxma6UPCtfvizHksc2axGbEY7jW5euATrmJUI1',
                      'sender_id': 'FSTSMS',
                      'message': self.txt_Messeage_all.get('1.0',END),
                      'language': 'english',
                      'route': 'p',
                      'numbers': k1
                  }
                  response = requests.get(url, params=params)
                  dic = response.json()
                  print(dic)
               messagebox.showinfo("Suceesfull","all messeage send")
               con.commit()
         con.close()
     # def send_email_all(self):
     #     email = Toplevel()
     #     email.title("Send E_mail to all student")
     #     email.geometry("450x350+0+0")
     #
     #     self.password_1_var = StringVar()
     #
     #     frame_4 = Frame(email, bd=4, relief=RIDGE, bg="red")
     #     frame_4.place(x=20, y=20, width=400, height=300)
     #
     #     Messeage_all = Label(frame_4, text="Messeage", bg="red", fg="white", font=("times new roman", 20, "bold"))
     #     Messeage_all.grid(row=1, column=0, pady=40, padx=9, sticky="w")
     #
     #     self.txt_Messeage_all_email = Text(frame_4, width=65, height=15, font=("", 4))
     #     self.txt_Messeage_all_email.grid(row=1, column=1, pady=20, padx=10, sticky="w")
     #
     #     password = Label(frame_4, text="password", bg="red", fg="white", font=("times new roman", 20, "bold"))
     #     password.grid(row=2, column=0, pady=10, padx=9, sticky="w")
     #
     #     password_txt = Entry(frame_4, show='*',textvariable=self.password_1_var, font=("times new roman", 15, "bold"),
     #                          bd=5, relief=GROOVE)
     #     password_txt.grid(row=2, column=1, pady=10, padx=7, sticky="w")
     #
     #     messeage = Button(frame_4, text="Send", width=20, height=2, command=self.all_email).grid(row=30, column=0,padx=10, pady=50)
     # def all_email(self):
     #     if self.password_1_var.get()=="":
     #         messagebox.showerror("ERROR","Password must reqiured")
     #     else:
     #       con = pymysql.connect(host="localhost", user="root", password="", database="deepanshu")
     #       cur = con.cursor()
     #       cur.execute("select * from student")
     #       rows = cur.fetchall()
     #       if len(rows) != 0:
     #           j = 1
     #           for i in range(len(rows)):
     #               cur.execute("select Email from student where Roll_No=" + str(j))
     #               j = j + 1
     #               conta = cur.fetchall()
     #               for k in conta:
     #                   k1 = k
     #                   print(k1)
     #               ob = s.SMTP("smtp.gmail.com", 587)
     #               ob.starttls()
     #               ob.login("deepanshusharma1199@gmail.com", self.password_1_var.get())
     #               subject = "Student Mangement"
     #               msse = "Subject:{}\n\n{}".format(subject, self.txt_Messeage_all_email.get('1.0',END))
     #               ob.sendmail("deepanshusharma1199", k1, msse)
     #               messagebox.showinfo("SUCCESFULL", "E_mail send succesfully")
     #           con.commit()
     #       con.close()
root=Tk()
ob=Student(root)
root.mainloop()